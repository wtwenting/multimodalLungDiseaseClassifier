#!/usr/bin/env python3
"""Build a patient-level BIMCV X-ray/CT manifest from incrementally extracted files.

No external packages required. No images are modified or loaded into memory.
"""
import argparse
import csv
import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path

DEFAULT_ROOT = Path('/Users/wenting/Projects/BIMCV-COVID-19')
PATIENT = re.compile(r'sub-(S[0-9]+)', re.I)
SESSION = re.compile(r'ses-(E[0-9]+)', re.I)
FIELDS = ['patient_id', 'covid_status', 'xray_path', 'ct_path', 'xray_session',
          'ct_session', 'xray_count', 'ct_count', 'pair_status', 'date_check', 'notes']

def identity(path):
    s = str(path)
    p = PATIENT.search(s)
    e = SESSION.search(s)
    return (p.group(1).upper() if p else None,
            e.group(1).upper() if e else None)

def discover(folder, modality):
    if not folder.is_dir():
        return [], f'Missing directory: {folder}'
    extensions = ('.png',) if modality == 'xray' else ('.nii', '.nii.gz')
    found = []
    for p in folder.rglob('*'):
        if not p.is_file() or not p.name.lower().endswith(extensions):
            continue
        patient, session = identity(p)
        if patient:
            found.append((patient, session, p))
    return found, None

def sort_key(record):
    _, session, path = record
    # Deterministic only; NOT a clinical-quality or chronological ranking.
    return (session or '', str(path))

def write_csv(path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    ap.add_argument('--output', type=Path, default=None)
    args = ap.parse_args()
    root = args.root.expanduser().resolve()
    out = (args.output or root / 'dataAnalysis/output').expanduser().resolve()
    rows, details = [], []
    errors = []
    for status, dirname in [('Negative', 'covidNegative'), ('Positive', 'covidPositive')]:
        xs, err = discover(root / 'data' / dirname / 'xray', 'xray')
        if err: errors.append(err)
        cs, err = discover(root / 'data' / dirname / 'ct', 'ct')
        if err: errors.append(err)
        xmap, cmap = defaultdict(list), defaultdict(list)
        for r in xs: xmap[r[0]].append(r)
        for r in cs: cmap[r[0]].append(r)
        for patient in sorted(xmap.keys() | cmap.keys()):
            xr = sorted(xmap[patient], key=sort_key)
            cr = sorted(cmap[patient], key=sort_key)
            # Avoid choosing a CT by filename alone as if it were clinically optimal.
            # Candidate files are fully listed in the companion inventory.
            paired = bool(xr and cr)
            selected_x = xr[0] if xr else None
            selected_c = cr[0] if cr else None
            rows.append({
                'patient_id': patient, 'covid_status': status,
                'xray_path': str(selected_x[2]) if selected_x else '',
                'ct_path': str(selected_c[2]) if selected_c else '',
                'xray_session': selected_x[1] or '' if selected_x else '',
                'ct_session': selected_c[1] or '' if selected_c else '',
                'xray_count': len(xr), 'ct_count': len(cr),
                'pair_status': 'CANDIDATE_PAIR' if paired else 'MISSING_CT' if xr else 'MISSING_XRAY',
                'date_check': 'NOT_VERIFIED' if paired else 'NOT_APPLICABLE',
                'notes': 'Lexicographic placeholder selection; validate study dates, CT series, quality and labels before training' if paired else 'Waiting for other modality or download',
            })
            for modality, group in [('xray', xr), ('ct', cr)]:
                for _, session, path in group:
                    details.append({'patient_id': patient, 'covid_status': status,
                                    'modality': modality, 'session_id': session or '',
                                    'file_path': str(path), 'size_bytes': path.stat().st_size})
    write_csv(out / 'paired_patient_manifest.csv', rows, FIELDS)
    write_csv(out / 'patient_image_inventory.csv', details,
              ['patient_id', 'covid_status', 'modality', 'session_id', 'file_path', 'size_bytes'])
    total = sum(r['pair_status'] == 'CANDIDATE_PAIR' for r in rows)
    print(f'Patients found: {len(rows)}; candidate paired patients: {total}')
    print(f'Manifest: {out / "paired_patient_manifest.csv"}')
    print(f'All image files: {out / "patient_image_inventory.csv"}')
    for error in errors:
        print('WARNING:', error)
    print('CAUTION: Candidate pairs share patient IDs, but exam dates and CT series are NOT validated.')
    print('Rerun as new archives are extracted; output CSVs are regenerated.')

if __name__ == '__main__':
    main()
