#!/usr/bin/env python3
"""Incremental BIMCV downloader: negatives first, then positives.

Requires macOS/Linux curl and Python 3.9+. No pip packages required.
"""
import argparse
import gzip
import json
import subprocess
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

NEGATIVE = '''ao ax az bf bg bn cc ck ct'''.split()
POSITIVE = '''kb lf ma os ot pd qe qj qq qr qz rg rl sn sy vq'''.split()
BASE_URLS = {
    'negative': 'https://b2drop.bsc.es/nextcloud/public.php/dav/files/BIMCV-COVID19-cIter_1_2-Negative/',
    'positive': 'https://b2drop.bsc.es/nextcloud/public.php/dav/files/BIMCV-COVID19-cIter_1_2_3/',
}


def remote_size(url):
    request = Request(url, method='HEAD', headers={'User-Agent': 'BIMCV-research-downloader/1.0'})
    with urlopen(request, timeout=90) as response:
        length = response.headers.get('Content-Length')
        if response.status != 200 or not length or not length.isdigit():
            raise ValueError(f'Unexpected HEAD response: {response.status}, length={length}')
        return int(length)


def gzip_valid(path):
    try:
        with gzip.open(path, 'rb') as stream:
            while stream.read(4 * 1024 * 1024):
                pass
        return True
    except (OSError, EOFError):
        return False


def download_one(kind, part, destination, attempts, verify_gzip):
    prefix = 'covid19_neg' if kind == 'negative' else 'covid19_posi'
    filename = f'{prefix}_subjects_part{part}.tar.gz'
    url = BASE_URLS[kind] + filename
    target = destination / filename
    partial = destination / (filename + '.partial')
    marker = destination / (filename + '.verified.json')
    print(f'\n[{kind.upper()}] {filename}', flush=True)
    try:
        expected = remote_size(url)
    except (HTTPError, URLError, ValueError, TimeoutError) as exc:
        print(f'  ERROR: cannot check remote file: {exc}', flush=True)
        return False
    if target.exists() and target.stat().st_size == expected:
        if marker.exists():
            try:
                info = json.loads(marker.read_text())
                if info.get('bytes') == expected and info.get('gzip_ok'):
                    print(f'  SKIP: already downloaded and verified ({expected:,} bytes)', flush=True)
                    return True
            except (OSError, ValueError):
                pass
        print('  Existing full-size file: verifying integrity...', flush=True)
        if gzip_valid(target):
            marker.write_text(json.dumps({'bytes': expected, 'gzip_ok': True}))
            print('  SKIP: existing archive verified', flush=True)
            return True
        print('  Existing file corrupted; moving aside', flush=True)
        target.rename(target.with_name(target.name + '.corrupt-' + str(int(time.time()))))
        marker.unlink(missing_ok=True)
    elif target.exists():
        print('  Existing file has wrong size; moving to .partial for resume', flush=True)
        if not partial.exists():
            target.rename(partial)
        else:
            target.rename(target.with_name(target.name + '.wrong-size-' + str(int(time.time()))))
        marker.unlink(missing_ok=True)
    for attempt in range(1, attempts + 1):
        print(f'  Download attempt {attempt}/{attempts}', flush=True)
        # -C - resumes a partial transfer if the server supports HTTP ranges.
        # -f prevents treating HTTP errors as successful downloads.
        cmd = ['curl', '--fail', '--location', '--continue-at', '-', '--retry', '3',
               '--retry-delay', '10', '--connect-timeout', '40', '--speed-time', '120',
               '--speed-limit', '1024', '--output', str(partial), url]
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            print(f'  curl failed (exit {result.returncode})', flush=True)
            time.sleep(5)
            continue
        actual = partial.stat().st_size if partial.exists() else 0
        if actual != expected:
            print(f'  INCOMPLETE: {actual:,}/{expected:,} bytes; will resume', flush=True)
            time.sleep(5)
            continue
        if verify_gzip:
            print('  Verifying gzip CRC (may take several minutes)...', flush=True)
            if not gzip_valid(partial):
                print('  FAILED gzip check; quarantining bad download', flush=True)
                partial.rename(partial.with_name(partial.name + '.corrupt-' + str(int(time.time()))))
                time.sleep(5)
                continue
        partial.replace(target)
        if verify_gzip:
            marker.write_text(json.dumps({'bytes': expected, 'gzip_ok': True}))
        print(f'  OK: {target} ({actual:,} bytes)', flush=True)
        return True
    print(f'  FAILED: {filename} (kept partial download if present)', flush=True)
    return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dir', type=Path, default=Path.home() / 'Downloads', help='Archive destination (default: ~/Downloads)')
    parser.add_argument('--attempts', type=int, default=3, help='Attempts per archive (default: 3)')
    parser.add_argument('--only', choices=['all', 'negative', 'positive'], default='all')
    parser.add_argument('--no-gzip-check', action='store_true', help='Skip full gzip CRC check for newly downloaded files (not recommended)')
    args = parser.parse_args()
    args.dir.mkdir(parents=True, exist_ok=True)
    results = []
    groups = [('negative', NEGATIVE), ('positive', POSITIVE)]
    for kind, parts in groups:
        if args.only not in ('all', kind):
            continue
        for part in parts:
            ok = download_one(kind, part, args.dir, args.attempts, not args.no_gzip_check)
            results.append((kind, part, ok))
    failures = [(kind, part) for kind, part, ok in results if not ok]
    print(f'\nFinished: {len(results) - len(failures)}/{len(results)} archives available and verified.')
    if failures:
        print('Failed:', ', '.join(f'{kind}:part{part}' for kind, part in failures))
        raise SystemExit(1)


if __name__ == '__main__':
    main()
