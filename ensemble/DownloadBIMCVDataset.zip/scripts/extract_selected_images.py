#!/usr/bin/env python3
"""Incrementally extract selected BIMCV CT volumes and X-rays from downloaded archives.

No third-party dependencies. Never extracts unrelated patients or entire archives.
Completed archives are skipped on subsequent runs unless --force is supplied.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from collections import defaultdict

ROOT = Path('/Users/wenting/Projects/BIMCV-COVID-19')
ARCHIVE_PATTERN = re.compile(r'^covid19_(?:posi|pos|neg)_subjects_part[a-z]+\.tar\.gz$', re.I)
LOCAL_ARCHIVE_PATTERN = re.compile(r'^(covid19_(?:posi|pos|neg)_subjects_part[a-z]+)(?:_(?:webdav|fresh|retry))?\.tar\.gz$', re.I)
PATIENT_PATTERN = re.compile(r'(?:^|/)sub-(S\d+)(?:/|_)', re.I)
SESSION_PATTERN = re.compile(r'(?:^|/)ses-(E\d+)(?:/|_)', re.I)

def normalize_status(raw):
    value = str(raw).strip().lower()
    if value in ('positive', 'pos', 'posi', 'covidpositive', 'covid-positive'):
        return 'Positive'
    if value in ('negative', 'neg', 'covidnegative', 'covid-negative'):
        return 'Negative'
    raise ValueError(f'Unknown COVID status: {raw!r}')

def normalize_pid(raw):
    match = re.fullmatch(r'(?:sub-)?(S\d+)', str(raw).strip(), re.I)
    if not match:
        raise ValueError(f'Invalid patient ID: {raw!r}')
    return match.group(1).upper()

def load_mapping(path):
    selected = defaultdict(set)
    with path.open(newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        required = {'Patient ID', 'COVID status', 'Archive', 'X-ray', 'CT'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError(f'Mapping missing columns: {sorted(required - set(reader.fieldnames or []))}')
        for row in reader:
            pid = normalize_pid(row['Patient ID'])
            status = normalize_status(row['COVID status'])
            archive = Path(row['Archive'].strip()).name
            if not ARCHIVE_PATTERN.fullmatch(archive):
                raise ValueError(f'Unexpected archive filename: {archive!r}')
            if status == 'Positive' and 'neg_' in archive.lower():
                raise ValueError(f'Positive status but negative archive: {archive}')
            if status == 'Negative' and 'neg_' not in archive.lower():
                raise ValueError(f'Negative status but positive archive: {archive}')
            mods = set()
            if row['X-ray'].strip().lower() in ('yes', 'true', '1'):
                mods.add('xray')
            if row['CT'].strip().lower() in ('yes', 'true', '1'):
                mods.add('ct')
            selected[(status, archive, pid)].update(mods)
    return selected

def find_local_archives(downloads):
    """Group alternative local filenames by canonical BIMCV archive name."""
    found = defaultdict(list)
    for path in downloads.iterdir():
        if not path.is_file():
            continue
        match = LOCAL_ARCHIVE_PATTERN.fullmatch(path.name)
        if match:
            canonical = match.group(1).lower() + '.tar.gz'
            found[canonical].append(path)
    # Prefer standard name, then larger copies; validity is checked before use.
    for canonical, paths in found.items():
        paths.sort(key=lambda p: (p.name.lower() != canonical, -p.stat().st_size, p.name))
    return found


def validate_archive(path):
    """Read entire gzip/tar stream; detects truncated and corrupt archives."""
    try:
        with tarfile.open(path, mode='r|gz') as tar:
            for member in tar:
                if member.isfile():
                    stream = tar.extractfile(member)
                    if stream is None:
                        raise OSError(f'Cannot read {member.name}')
                    while stream.read(1024 * 1024):
                        pass
        return True, ''
    except (OSError, EOFError, tarfile.TarError, ValueError) as exc:
        return False, str(exc)


def classify_member(name):
    low = name.lower()
    if low.endswith('.nii.gz') and re.search(r'_ct\.nii\.gz$', low):
        return 'ct'
    if low.endswith('.png') and re.search(r'_(?:cr|dx)\.png$', low):
        return 'xray'
    return None

def safe_member_name(name):
    p = Path(name)
    return not p.is_absolute() and '..' not in p.parts and '\\' not in name

def write_csv(path, rows):
    cols = ['COVID status', 'Archive', 'Status', 'Selected patients', 'Extracted files', 'Already existing files', 'Detail']
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)

def atomic_json(path, data):
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)

def destination_for(root, status, modality, pid, member_name):
    session_match = SESSION_PATTERN.search(member_name)
    session = ('ses-' + session_match.group(1).upper()) if session_match else 'unknown_session'
    cohort_dir = 'covidPositive' if status == 'Positive' else 'covidNegative'
    return root / 'data' / cohort_dir / modality / ('sub-' + pid) / session / Path(member_name).name


def verify_extracted_members(archive_path, root, status, patients):
    """Require every selected image in the archive to exist at the expected size."""
    count = 0
    try:
        with tarfile.open(archive_path, mode='r|gz') as tar:
            for member in tar:
                if not member.isfile():
                    continue
                if not safe_member_name(member.name):
                    return False, count, 'Unsafe path in archive'
                modality = classify_member(member.name)
                match = PATIENT_PATTERN.search(member.name) if modality else None
                if not match:
                    continue
                pid = match.group(1).upper()
                if modality not in patients.get(pid, set()):
                    continue
                count += 1
                dest = destination_for(root, status, modality, pid, member.name)
                if not dest.is_file() or dest.stat().st_size != member.size:
                    return False, count, f'Missing or wrong-size extracted file: {dest}'
        return True, count, ''
    except (OSError, EOFError, tarfile.TarError, ValueError) as exc:
        return False, count, str(exc)


def delete_verified_copies(candidates, root, status, patients, dry_run=False):
    """Delete local copies only after selected images have been checked against archive."""
    deleted = []
    errors = []
    for path in candidates:
        valid, count, reason = verify_extracted_members(path, root, status, patients)
        if not valid:
            errors.append(f'{path.name}: {reason}')
            continue
        if dry_run:
            deleted.append(f'WOULD DELETE {path.name} ({count} images verified)')
        else:
            try:
                path.unlink()
                deleted.append(f'DELETED {path.name} ({count} images verified)')
            except OSError as exc:
                errors.append(f'{path.name}: deletion failed: {exc}')
    return deleted, errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--downloads', type=Path, default=Path.home() / 'Downloads')
    parser.add_argument('--mapping', type=Path)
    parser.add_argument('--force', action='store_true', help='Reprocess completed archives')
    parser.add_argument('--dry-run', action='store_true', help='Show which archives would be processed without extracting or deleting')
    parser.add_argument('--keep-archives', action='store_true', help='Never delete downloaded archives')
    args = parser.parse_args()
    root = args.root.expanduser()
    mapping = (args.mapping or root / 'dataAnalysis/output/patient_archive_mapping.csv').expanduser()
    downloads = args.downloads.expanduser()
    if not mapping.is_file():
        parser.error(f'Mapping CSV not found: {mapping}')
    if not downloads.is_dir():
        parser.error(f'Downloads folder not found: {downloads}')
    selected = load_mapping(mapping)
    groups = defaultdict(dict)
    for (status, archive, pid), mods in selected.items():
        groups[(status, archive)][pid] = mods
    output = root / 'dataAnalysis/output'
    output.mkdir(parents=True, exist_ok=True)
    state_file = output / 'archive_extraction_state.json'
    state = json.loads(state_file.read_text(encoding='utf-8')) if state_file.exists() else {}
    reports = []
    local_archives = find_local_archives(downloads)
    for (status, archive), patients in sorted(groups.items()):
        candidates = local_archives.get(archive.lower(), [])
        archive_path = candidates[0] if candidates else downloads / archive
        record = {'COVID status': status, 'Archive': archive, 'Status': '',
                  'Selected patients': len(patients), 'Extracted files': 0,
                  'Already existing files': 0, 'Detail': ''}
        # Include requested patient/modality selection in the checkpoint identity.
        selection_json = json.dumps({k: sorted(v) for k, v in sorted(patients.items())}, sort_keys=True)
        selection_hash = hashlib.sha256(selection_json.encode()).hexdigest()
        key = f'{status}/{archive}'
        # Completed logical archives are skipped regardless of local suffix or duplicate copies.
        previous = state.get(key, {})
        if not candidates:
            if previous.get('complete') and previous.get('selection_hash') == selection_hash:
                record.update(Status='SKIPPED_ARCHIVE_REMOVED', Detail='Previously completed; source archive no longer on disk')
                print(f'SKIP  {archive} (already extracted; archive absent)')
            else:
                record.update(Status='MISSING', Detail='Archive not downloaded yet')
            reports.append(record)
            continue
        if not args.force and previous.get('complete') and previous.get('selection_hash') == selection_hash:
            record.update(Status='SKIPPED_COMPLETE', Detail='Logical archive previously completed')
            reports.append(record)
            print(f'SKIP  {archive}')
            if not args.keep_archives:
                messages, errors = delete_verified_copies(candidates, root, status, patients, dry_run=args.dry_run)
                for message in messages:
                    print('  ' + message)
                if errors:
                    print('  KEEP: ' + '; '.join(errors), file=sys.stderr)
                record['Detail'] = '; '.join(messages + errors)
            write_csv(output / 'archive_extraction_report.csv', reports)
            continue
        if not args.dry_run:
            errors = []
            archive_path = None
            for candidate in candidates:
                valid, reason = validate_archive(candidate)
                if valid:
                    archive_path = candidate
                    break
                errors.append(f'{candidate.name}: {reason}')
            if archive_path is None:
                record.update(Status='FAILED', Detail='All local copies invalid: ' + '; '.join(errors))
                reports.append(record)
                print(f'ERROR {archive}: no valid copy', file=sys.stderr)
                continue
        st = archive_path.stat()
        identity = {'size': st.st_size, 'mtime_ns': st.st_mtime_ns, 'selection_hash': selection_hash, 'local_filename': archive_path.name}
        if args.dry_run:
            record.update(Status='WOULD_PROCESS', Detail=f'{st.st_size:,} archive bytes')
            reports.append(record)
            print(f'PLAN  {archive}: {len(patients)} patients')
            continue
        print(f'OPEN  {archive}: {len(patients)} patients', flush=True)
        extracted, existing = 0, 0
        # Stream the gzip archive sequentially: no full archive extraction, low RAM use.
        try:
            with tarfile.open(archive_path, mode='r|gz') as tar:
                for member in tar:
                    if not member.isfile() or not safe_member_name(member.name):
                        continue
                    modality = classify_member(member.name)
                    if modality is None:
                        continue
                    pid_match = PATIENT_PATTERN.search(member.name)
                    if not pid_match:
                        continue
                    pid = pid_match.group(1).upper()
                    if modality not in patients.get(pid, set()):
                        continue
                    destination = destination_for(root, status, modality, pid, member.name)
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    if destination.exists() and destination.stat().st_size == member.size:
                        existing += 1
                        continue
                    stream = tar.extractfile(member)
                    if stream is None:
                        continue
                    # Write to a temporary file and rename only after the full member is read.
                    fd, temp_name = tempfile.mkstemp(prefix='.partial_', dir=destination.parent)
                    try:
                        with os.fdopen(fd, 'wb') as out:
                            remaining = member.size
                            while remaining:
                                chunk = stream.read(min(1024 * 1024, remaining))
                                if not chunk:
                                    raise EOFError(f'Unexpected EOF extracting {member.name}')
                                out.write(chunk)
                                remaining -= len(chunk)
                        os.replace(temp_name, destination)
                        extracted += 1
                    finally:
                        if os.path.exists(temp_name):
                            os.unlink(temp_name)
            # Confirm all selected images are present before checkpointing or deleting the source.
            verified, verified_count, verify_reason = verify_extracted_members(archive_path, root, status, patients)
            if not verified:
                raise OSError(f'Post-extraction verification failed: {verify_reason}')
            state[key] = {'identity': identity, 'selection_hash': selection_hash, 'complete': True,
                          'finished_utc': datetime.now(timezone.utc).isoformat(),
                          'extracted_files': extracted, 'already_existing_files': existing}
            atomic_json(state_file, state)
            record.update(Status='COMPLETE', **{'Extracted files': extracted, 'Already existing files': existing})
            print(f'OK    {archive} (from {archive_path.name}): {extracted} extracted, {existing} already present')
            if not args.keep_archives:
                messages, errors = delete_verified_copies(candidates, root, status, patients)
                for message in messages:
                    print('  ' + message)
                if errors:
                    print('  KEEP: ' + '; '.join(errors), file=sys.stderr)
                record['Detail'] = '; '.join(messages + errors)
        except (OSError, EOFError, tarfile.TarError) as e:
            # Never checkpoint failed archives. Rerun will retry, skipping complete output files.
            state.pop(key, None)
            atomic_json(state_file, state)
            record.update(Status='FAILED', **{'Extracted files': extracted, 'Already existing files': existing}, Detail=str(e))
            print(f'ERROR {archive}: {e}', file=sys.stderr)
        reports.append(record)
        write_csv(output / 'archive_extraction_report.csv', reports)
    report_path = output / 'archive_extraction_report.csv'
    write_csv(report_path, reports)
    from collections import Counter
    print(f'\nReport: {report_path}')
    print('Statuses:', dict(Counter(r['Status'] for r in reports)))
    print('Checkpoint:', state_file)

if __name__ == '__main__':
    main()
