#!/usr/bin/env python3
"""Download ONE BIMCV archive, extract selected patient images, verify, delete, repeat.

Self-contained: combines the user's downloader and extractor workflows.
Uses only Python stdlib and macOS curl. Never deletes an archive unless extraction
has been verified against its TAR member listing. Existing extraction checkpoints
are respected, including archives already deleted on earlier runs.
"""
import argparse
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import tarfile
import tempfile
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen


# Reused extraction helpers from the supplied extract_selected_images.py
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from collections import defaultdict

ROOT = Path('/Users/wenting/Projects/BIMCV-COVID-19')
ARCHIVE_PATTERN = re.compile(r'^covid19_(?:posi|pos|neg)_subjects_part[a-z]+\.tar\.gz$', re.I)
LOCAL_ARCHIVE_PATTERN = re.compile(r'^(covid19_(?:posi|pos|neg)_subjects_part[a-z]+)(?:_(?:webdav|fresh|retry|recovered))?\.tar\.gz$', re.I)
PATIENT_PATTERN = re.compile(r'(?:^|/)sub-(S\d+)(?:/|_)', re.I)
SESSION_PATTERN = re.compile(r'(?:^|/)ses-(E\d+)(?:/|_)', re.I)

def normalize_status(raw):
    value = str(raw).strip().lower()
    if value in ('positive', 'pos', 'posi', 'covidpositive', 'covid-positive'):
        return 'Positive'
    if value in ('negative', 'neg', 'covidnegative', 'covid-negative'):
        return 'Negative'
    raise ValueError(f'Unknown COVID status: {raw!r}')

def normalize_pid(raw):
    match = re.fullmatch(r'(?:sub-)?(S\d+)', str(raw).strip(), re.I)
    if not match:
        raise ValueError(f'Invalid patient ID: {raw!r}')
    return match.group(1).upper()

def load_mapping(path):
    selected = defaultdict(set)
    with path.open(newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        required = {'Patient ID', 'COVID status', 'Archive', 'X-ray', 'CT'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError(f'Mapping missing columns: {sorted(required - set(reader.fieldnames or []))}')
        for row in reader:
            pid = normalize_pid(row['Patient ID'])
            status = normalize_status(row['COVID status'])
            archive = Path(row['Archive'].strip()).name
            if not ARCHIVE_PATTERN.fullmatch(archive):
                raise ValueError(f'Unexpected archive filename: {archive!r}')
            if status == 'Positive' and 'neg_' in archive.lower():
                raise ValueError(f'Positive status but negative archive: {archive}')
            if status == 'Negative' and 'neg_' not in archive.lower():
                raise ValueError(f'Negative status but positive archive: {archive}')
            mods = set()
            if row['X-ray'].strip().lower() in ('yes', 'true', '1'):
                mods.add('xray')
            if row['CT'].strip().lower() in ('yes', 'true', '1'):
                mods.add('ct')
            selected[(status, archive, pid)].update(mods)
    return selected

def find_local_archives(downloads):
    """Group alternative local filenames by canonical BIMCV archive name."""
    found = defaultdict(list)
    for path in downloads.iterdir():
        if not path.is_file():
            continue
        match = LOCAL_ARCHIVE_PATTERN.fullmatch(path.name)
        if match:
            canonical = match.group(1).lower() + '.tar.gz'
            found[canonical].append(path)
    # Prefer standard name, then larger copies; validity is checked before use.
    for canonical, paths in found.items():
        paths.sort(key=lambda p: (p.name.lower() != canonical, -p.stat().st_size, p.name))
    return found


def validate_archive(path):
    """Read entire gzip/tar stream; detects truncated and corrupt archives."""
    try:
        with tarfile.open(path, mode='r|gz') as tar:
            for member in tar:
                if member.isfile():
                    stream = tar.extractfile(member)
                    if stream is None:
                        raise OSError(f'Cannot read {member.name}')
                    while stream.read(1024 * 1024):
                        pass
        return True, ''
    except (OSError, EOFError, tarfile.TarError, ValueError) as exc:
        return False, str(exc)


def classify_member(name):
    low = name.lower()
    if low.endswith('.nii.gz') and re.search(r'_ct\.nii\.gz$', low):
        return 'ct'
    if low.endswith('.png') and re.search(r'_(?:cr|dx)\.png$', low):
        return 'xray'
    return None

def safe_member_name(name):
    p = Path(name)
    return not p.is_absolute() and '..' not in p.parts and '\\' not in name

def write_csv(path, rows):
    cols = ['COVID status', 'Archive', 'Status', 'Selected patients', 'Extracted files', 'Already existing files', 'Detail']
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)

def atomic_json(path, data):
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)

def destination_for(root, status, modality, pid, member_name):
    session_match = SESSION_PATTERN.search(member_name)
    session = ('ses-' + session_match.group(1).upper()) if session_match else 'unknown_session'
    cohort_dir = 'covidPositive' if status == 'Positive' else 'covidNegative'
    return root / 'data' / cohort_dir / modality / ('sub-' + pid) / session / Path(member_name).name


def verify_extracted_members(archive_path, root, status, patients):
    """Require every selected image in the archive to exist at the expected size."""
    count = 0
    try:
        with tarfile.open(archive_path, mode='r|gz') as tar:
            for member in tar:
                if not member.isfile():
                    continue
                if not safe_member_name(member.name):
                    return False, count, 'Unsafe path in archive'
                modality = classify_member(member.name)
                match = PATIENT_PATTERN.search(member.name) if modality else None
                if not match:
                    continue
                pid = match.group(1).upper()
                if modality not in patients.get(pid, set()):
                    continue
                count += 1
                dest = destination_for(root, status, modality, pid, member.name)
                if not dest.is_file() or dest.stat().st_size != member.size:
                    return False, count, f'Missing or wrong-size extracted file: {dest}'
        return True, count, ''
    except (OSError, EOFError, tarfile.TarError, ValueError) as exc:
        return False, count, str(exc)


def delete_verified_copies(candidates, root, status, patients, dry_run=False):
    """Delete local copies only after selected images have been checked against archive."""
    deleted = []
    errors = []
    for path in candidates:
        valid, count, reason = verify_extracted_members(path, root, status, patients)
        if not valid:
            errors.append(f'{path.name}: {reason}')
            continue
        if dry_run:
            deleted.append(f'WOULD DELETE {path.name} ({count} images verified)')
        else:
            try:
                path.unlink()
                deleted.append(f'DELETED {path.name} ({count} images verified)')
            except OSError as exc:
                errors.append(f'{path.name}: deletion failed: {exc}')
    return deleted, errors



ROOT = Path('/Users/wenting/Projects/BIMCV-COVID-19')
NEGATIVE = 'af an as av bl bm bo bs ca cy dc dk'.split()
# Existing positive queue retained from user's prior downloader.
POSITIVE = 'kb lf ma os ot pd qe qj qq qr qz rg rl sn sy vq'.split()
BASE = {
    'Negative': 'https://b2drop.bsc.es/nextcloud/public.php/dav/files/BIMCV-COVID19-cIter_1_2-Negative/',
    'Positive': 'https://b2drop.bsc.es/nextcloud/public.php/dav/files/BIMCV-COVID19-cIter_1_2_3/',
}


def canonical(status, part):
    return f"covid19_{'neg' if status == 'Negative' else 'posi'}_subjects_part{part}.tar.gz"


def selected_groups(mapping):
    selected = load_mapping(mapping)
    groups = defaultdict(dict)
    for (status, archive, pid), mods in selected.items():
        groups[(status, archive)][pid] = mods
    return groups


def selection_hash(patients):
    payload = json.dumps({k: sorted(v) for k, v in sorted(patients.items())}, sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()


def read_state(path):
    return json.loads(path.read_text()) if path.exists() else {}


def remote_size(url):
    with urlopen(Request(url, method='HEAD', headers={'User-Agent': 'BIMCV-study/1.0'}), timeout=90) as resp:
        size = resp.headers.get('Content-Length', '')
        if resp.status != 200 or not size.isdigit() or int(size) < 1024:
            raise ValueError(f'Invalid server response: HTTP {resp.status}, length={size}')
        return int(size)


def verified_archive(path, expected=None):
    if not path.is_file() or (expected is not None and path.stat().st_size != expected):
        return False, 'Missing or unexpected file size'
    return validate_archive(path)


def get_archive(status, archive, downloads, attempts):
    """Prefer an existing verified local copy, including _webdav suffixes."""
    candidates = find_local_archives(downloads).get(archive.lower(), [])
    for path in candidates:
        print(f'CHECK existing {path.name}', flush=True)
        ok, reason = verified_archive(path)
        if ok:
            return path
        print(f'  Invalid copy (kept): {reason}', flush=True)

    url = BASE[status] + archive
    expected = remote_size(url)
    target = downloads / archive
    # Never overwrite a corrupted standard-name copy; keep it for diagnosis.
    if target.exists():
        target = downloads / archive.replace('.tar.gz', '_recovered.tar.gz')
    partial = Path(str(target) + '.partial')
    for attempt in range(1, attempts + 1):
        print(f'DOWNLOAD {archive} attempt {attempt}/{attempts} ({expected:,} bytes)', flush=True)
        cmd = ['curl', '--fail', '--location', '--continue-at', '-', '--retry', '3',
               '--retry-delay', '10', '--connect-timeout', '40', '--speed-time', '120',
               '--speed-limit', '1024', '--output', str(partial), url]
        result = subprocess.run(cmd, check=False)
        if result.returncode or not partial.exists():
            print(f'  curl failed: {result.returncode}', flush=True)
            continue
        if partial.stat().st_size != expected:
            print(f'  Incomplete: {partial.stat().st_size:,}/{expected:,} bytes', flush=True)
            continue
        print('  Checking full TAR/gzip integrity...', flush=True)
        ok, reason = verified_archive(partial, expected)
        if ok:
            os.replace(partial, target)
            return target
        print(f'  Invalid complete-size download: {reason}', flush=True)
        partial.rename(partial.with_name(partial.name + '.corrupt-' + str(int(time.time()))))
    raise RuntimeError(f'Download failed for {archive}; any partial download was preserved')


def extract_and_verify(path, root, status, patients):
    """Streaming extraction of selected members only; atomic file writes."""
    extracted = existing = 0
    with tarfile.open(path, mode='r|gz') as tar:
        for member in tar:
            if not member.isfile():
                continue
            if not safe_member_name(member.name):
                raise ValueError(f'Unsafe archive member: {member.name}')
            modality = classify_member(member.name)
            match = PATIENT_PATTERN.search(member.name) if modality else None
            if not match:
                continue
            pid = match.group(1).upper()
            if modality not in patients.get(pid, set()):
                continue
            destination = destination_for(root, status, modality, pid, member.name)
            if destination.is_file() and destination.stat().st_size == member.size:
                existing += 1
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            stream = tar.extractfile(member)
            if stream is None:
                raise OSError(f'Cannot read selected image {member.name}')
            fd, tmp = tempfile.mkstemp(prefix='.partial_', dir=destination.parent)
            try:
                with os.fdopen(fd, 'wb') as out:
                    remaining = member.size
                    while remaining:
                        chunk = stream.read(min(1024 * 1024, remaining))
                        if not chunk:
                            raise EOFError(f'Truncated image: {member.name}')
                        out.write(chunk)
                        remaining -= len(chunk)
                os.replace(tmp, destination)
                extracted += 1
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)
    ok, count, reason = verify_extracted_members(path, root, status, patients)
    if not ok or count == 0:
        raise RuntimeError(reason or 'No selected images found; refusing to delete archive')
    return extracted, existing, count


def save_report(path, rows):
    fields = ['COVID status', 'Archive', 'Status', 'Selected patients', 'Extracted files', 'Already existing files', 'Verified files', 'Detail']
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=ROOT)
    p.add_argument('--downloads', type=Path, default=Path.home() / 'Downloads')
    p.add_argument('--mapping', type=Path)
    p.add_argument('--only', choices=['negative', 'positive', 'all'], default='negative')
    p.add_argument('--attempts', type=int, default=3)
    p.add_argument('--dry-run', action='store_true', help='Show planned actions without download/extract/delete')
    p.add_argument('--keep-archives', action='store_true', help='Do not delete verified source archives')
    args = p.parse_args()
    root = args.root.expanduser()
    downloads = args.downloads.expanduser()
    mapping = (args.mapping or root / 'dataAnalysis/output/patient_archive_mapping.csv').expanduser()
    if not mapping.is_file():
        p.error(f'Missing mapping: {mapping}')
    downloads.mkdir(parents=True, exist_ok=True)
    output = root / 'dataAnalysis/output'
    output.mkdir(parents=True, exist_ok=True)
    state_path = output / 'archive_extraction_state.json'  # shared with existing extractor
    report_path = output / 'download_extract_cleanup_report.csv'
    groups = selected_groups(mapping)
    jobs = []
    if args.only in ('negative', 'all'):
        jobs.extend(('Negative', canonical('Negative', part)) for part in NEGATIVE)
    if args.only in ('positive', 'all'):
        jobs.extend(('Positive', canonical('Positive', part)) for part in POSITIVE)
    rows = []
    failures = 0
    for status, archive in jobs:
        patients = groups.get((status, archive), {})
        record = {'COVID status': status, 'Archive': archive, 'Status': '',
                  'Selected patients': len(patients), 'Extracted files': 0,
                  'Already existing files': 0, 'Verified files': 0, 'Detail': ''}
        key = f'{status}/{archive}'
        digest = selection_hash(patients)
        state = read_state(state_path)
        previous = state.get(key, {})
        print(f'\n[{status}] {archive} ({len(patients)} selected patients)', flush=True)
        if not patients:
            record.update(Status='NOT_IN_MAPPING', Detail='No eligible patient/modality entries; not downloaded')
        elif previous.get('complete') and previous.get('selection_hash') == digest:
            # Already completed, possibly with archive removed by previous extractor.
            candidates = find_local_archives(downloads).get(archive.lower(), [])
            if not candidates:
                record.update(Status='SKIPPED_COMPLETE', Detail='Checkpoint exists; archive already absent')
                print('SKIP completed archive; no source file on disk', flush=True)
            elif args.dry_run:
                record.update(Status='WOULD_VERIFY_CLEANUP', Detail='Existing checkpoint; local archive present')
            else:
                # Check extracted output against archive before deleting.
                deleted, errors = ([], []) if args.keep_archives else delete_verified_copies(candidates, root, status, patients)
                record.update(Status='SKIPPED_COMPLETE' if not errors else 'CLEANUP_WARNING', Detail='; '.join(deleted + errors))
                for message in deleted + errors:
                    print(message, flush=True)
        elif args.dry_run:
            record.update(Status='WOULD_PROCESS', Detail='Will download or reuse local archive, extract, verify, and delete')
        else:
            try:
                source = get_archive(status, archive, downloads, args.attempts)
                print(f'EXTRACT selected patients from {source.name}', flush=True)
                extracted, existing, verified = extract_and_verify(source, root, status, patients)
                # Commit completion checkpoint BEFORE source deletion.
                state = read_state(state_path)
                state[key] = {'complete': True, 'selection_hash': digest,
                              'finished_utc': datetime.now(timezone.utc).isoformat(),
                              'local_filename': source.name, 'extracted_files': extracted,
                              'already_existing_files': existing, 'verified_files': verified}
                atomic_json(state_path, state)
                record.update(Status='COMPLETE', **{'Extracted files': extracted,
                              'Already existing files': existing, 'Verified files': verified})
                print(f'OK {archive}: {extracted} extracted, {existing} existing, {verified} verified', flush=True)
                if not args.keep_archives:
                    # Delete only after verifying each candidate copy against extracted files.
                    candidates = find_local_archives(downloads).get(archive.lower(), [])
                    deleted, errors = delete_verified_copies(candidates, root, status, patients)
                    for message in deleted + errors:
                        print(message, flush=True)
                    if errors:
                        record.update(Status='CLEANUP_WARNING', Detail='; '.join(errors))
            except Exception as exc:
                # On failure, leave source archive and any partial download in place.
                record.update(Status='FAILED', Detail=str(exc))
                failures += 1
                print(f'ERROR {archive}: {exc}', file=sys.stderr, flush=True)
        rows.append(record)
        save_report(report_path, rows)
    print(f'\nReport: {report_path}\nFailures: {failures}')
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
